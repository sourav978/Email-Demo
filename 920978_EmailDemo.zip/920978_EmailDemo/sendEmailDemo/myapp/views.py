from django.shortcuts import render,HttpResponse
from django.core.mail import send_mail,EmailMultiAlternatives
from sendEmailDemo.settings import EMAIL_HOST_USER

# Create your views here.
def index(request):
    if request.method=="POST":

        sub=request.POST.get("subject")
        msg=request.POST.get("message")
        #send_mail(sub,msg,EMAIL_HOST_USER,['shubhamchopade281998@gmail.com'])

        email=EmailMultiAlternatives(sub,msg,EMAIL_HOST_USER,['shubhamchopade281998@gmail.com','deshmukhavinash1998@gmail.com'])
        email.attach('django.png','static/images')
        email.send()
        return HttpResponse("email sent successfully")
    else:
        return render(request,'mail.html')